## BOUNCE EMAIL VALID CHECKER V1
BOUNCE EMAIL VALID CHECKER (PHP VERSION + EXE VESION FOR WINDOWS USERS + PYTHON VERSION)

**First Step**
----------
*Click <a href="https://www.youtube.com/AronTnXofficial">here</a> and Subscribe 2 <a href="https://www.youtube.com/AronTnXofficial">ARON-TN</a> .. ^_^*
----------

<img src="https://i.imgur.com/SEtiKIv.png" style="max-width:100%;">

Installation : 
------
         
    
 - PHP VERSION ?
   
               Just Download xampp
 - Windows Users
   
               Just Double Click On Bounce.exe
 - LINUX Users
   
               python3 Bounce.py
               

📧 Contact :
------
```
[+] Personal account : fb.com/amyr.gov.tn
[+] Facebook Page : fb.com/aron.tn
[+] Telegram : @aron_tn
[+] Telegram Channel : https://t.me/Aron_Tn_Store_Official
[+] Email : aron.tn.official@gmail.com
```

<br>©2021 Aron-Tn
