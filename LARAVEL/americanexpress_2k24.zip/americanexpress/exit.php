<?php

header("Location: https://www.americanexpress.com/?inav=NavLogo");

?>