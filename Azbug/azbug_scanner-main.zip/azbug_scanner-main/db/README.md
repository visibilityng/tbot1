### Note: Don't Delete All This Files Names !
- Url.txt [List Of Your Urls Do You Want To Scanning]
- dorks.txt [List Of Dorks, Used For Bing Grabber]
- wordlist.txt [List For Fuzzing & Discovering - Path Directory - You Can Add Your List As You Like] Length Lines : 9880
- sub_name.txt [List For Enumiration - Subdomains - Sub Takeover - You Can Add Your List As You Like] Length Lines : 263014 
